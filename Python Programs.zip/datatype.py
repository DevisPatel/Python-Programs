new=[1,2,3,4,5,'a','b']

print(new)
print('\n','\n')
print(type(new))

print([i**3 for i in range(1,6)])


